import { world, system } from "@minecraft/server";

// =====================================================
//  НАСТРОЙКИ
// =====================================================
const MAX_SPEED = 75;        // км/ч
const PRESS_COOLDOWN = 4;    // тиков между нажатиями (защита от двойного срабатывания)
const HORN_COOLDOWN = 30;    // тиков между гудками (звук идёт около 1.5 секунд)
const TRAIN_FAMILY = "mmt_train"; // любой поезд (из любого аддона) должен иметь эту "семью"
const DRIVER_TAG = "driver"; // тег машиниста: /tag @s add driver
const CONTROL_RADIUS = 32;   // управляется ближайший поезд в этом радиусе (блоки)
const DIMENSIONS = ["overworld", "nether", "the_end"];
const RAIL_Y = 0.0625;       // насколько поезд "приподнят" над низом блока рельса

// Шкала контроллера: позиция -> ускорение за тик
// отрицательные позиции = тормоз, положительные = газ
const MIN_NOTCH = -4;
const MAX_NOTCH = 3;
const ACCEL = {
  "-4": -0.8,
  "-3": -0.5,
  "-2": -0.3,
  "-1": -0.1,
  "0": 0,
  "1": 0.2,
  "2": 0.4,
  "3": 0.6,
};

// =====================================================
//  РЕЛЬСЫ
// =====================================================
// Середины сторон блока (x, z) и "наружная" нормаль каждой стороны
const EDGE = {
  N: { x: 0.5, z: 0,   nx: 0,  nz: -1 },
  S: { x: 0.5, z: 1,   nx: 0,  nz: 1 },
  W: { x: 0,   z: 0.5, nx: -1, nz: 0 },
  E: { x: 1,   z: 0.5, nx: 1,  nz: 0 },
};

// Форма рельса (rail_direction 0..9) -> [сторона A, высота A, сторона B, высота B]
// высота: 0 = низ блока, 1 = верх блока (подъём)
const SHAPES = [
  ["N", 0, "S", 0], // 0 север-юг
  ["W", 0, "E", 0], // 1 запад-восток
  ["W", 0, "E", 1], // 2 подъём на восток
  ["W", 1, "E", 0], // 3 подъём на запад
  ["N", 1, "S", 0], // 4 подъём на север
  ["N", 0, "S", 1], // 5 подъём на юг
  ["S", 0, "E", 0], // 6 поворот юг-восток
  ["S", 0, "W", 0], // 7 поворот юг-запад
  ["N", 0, "W", 0], // 8 поворот север-запад
  ["N", 0, "E", 0], // 9 поворот север-восток
];

const RAIL_TYPES = new Set([
  "minecraft:rail",
  "minecraft:golden_rail",
  "minecraft:detector_rail",
  "minecraft:activator_rail",
]);

// Ищет рельс в блоке (bx, by, bz), а если там нет - в блоке под ним (спуск)
function getRailAt(dim, bx, by, bz) {
  for (const y of [by, by - 1]) {
    const block = dim.getBlock({ x: bx, y: y, z: bz });
    if (block && RAIL_TYPES.has(block.typeId)) {
      const shape = block.permutation.getState("rail_direction");
      if (typeof shape === "number" && shape >= 0 && shape <= 9) {
        return { bx: bx, by: y, bz: bz, shape: shape };
      }
    }
  }
  return undefined;
}

// Двигает поезд по рельсам на dist блоков. Возвращает true, если упёрся (нет рельса).
function advanceTrain(train, st, distance) {
  const dim = train.dimension;
  let p = { x: train.location.x, y: train.location.y, z: train.location.z };
  let dist = distance;
  let blocked = false;
  let yaw = null;
  let snapped = false;

  for (let i = 0; i < 30; i++) {
    // смотрим чуть вперёд по ходу, чтобы на границе блоков выбрать следующий
    const lookX = p.x + st.hx * 0.01;
    const lookZ = p.z + st.hz * 0.01;
    const rail = getRailAt(dim, Math.floor(lookX), Math.floor(p.y), Math.floor(lookZ));
    if (!rail) {
      blocked = true;
      break;
    }
    snapped = true;

    const sh = SHAPES[rail.shape];
    const eA = EDGE[sh[0]];
    const eB = EDGE[sh[2]];
    const A = { x: rail.bx + eA.x, y: rail.by + RAIL_Y + sh[1], z: rail.bz + eA.z };
    const B = { x: rail.bx + eB.x, y: rail.by + RAIL_Y + sh[3], z: rail.bz + eB.z };

    const dx = B.x - A.x;
    const dz = B.z - A.z;
    const len = Math.sqrt(dx * dx + dz * dz);

    // где мы на отрезке A-B (0..1)
    let s = ((p.x - A.x) * dx + (p.z - A.z) * dz) / (len * len);
    s = Math.max(0, Math.min(1, s));

    // в какую сторону отрезка едем
    const sign = st.hx * dx + st.hz * dz >= 0 ? 1 : -1;
    const target = sign > 0 ? 1 : 0;
    const distToEnd = Math.abs(target - s) * len;
    const step = Math.min(dist, distToEnd);

    s += (sign * step) / len;
    p = {
      x: A.x + dx * s,
      y: A.y + (B.y - A.y) * s,
      z: A.z + dz * s,
    };
    dist -= step;
    yaw = (Math.atan2(-sign * dx, sign * dz) * 180) / Math.PI;

    if (step >= distToEnd - 1e-9) {
      // доехали до края блока: дальше едем наружу через эту сторону
      const e = sign > 0 ? eB : eA;
      st.hx = e.nx;
      st.hz = e.nz;
    }

    if (dist <= 1e-6) break;
  }

  if (snapped) {
    const options = yaw === null ? undefined : { rotation: { x: 0, y: yaw } };
    train.teleport(p, options);
    st.placed = true;
  }
  return blocked && dist > 1e-6;
}

// =====================================================
//  СОСТОЯНИЕ ПОЕЗДОВ
// =====================================================
const trainStates = new Map(); // ключ - id сущности поезда
const lastPress = new Map();   // ключ - id игрока
const lastHorn = new Map();    // ключ - id поезда

function getTrainState(train) {
  if (!trainStates.has(train.id)) {
    // начальное направление берём из поворота поезда, округляем до оси
    const yaw = (train.getRotation().y * Math.PI) / 180;
    const fx = -Math.sin(yaw);
    const fz = Math.cos(yaw);
    let hx = 0;
    let hz = 0;
    if (Math.abs(fx) > Math.abs(fz)) hx = fx > 0 ? 1 : -1;
    else hz = fz >= 0 ? 1 : -1;

    trainStates.set(train.id, {
      notch: 0,   // позиция контроллера
      speed: 0,   // км/ч
      dir: 1,     // 1 вперёд, -1 назад (для показа)
      hx: hx,     // направление движения по X
      hz: hz,     // направление движения по Z
      placed: false,
      soundKey: null, // какой звук хода сейчас играет
      soundNext: 0,   // когда запускать следующий повтор (тик)
    });
  }
  return trainStates.get(train.id);
}

// Ближайший поезд к игроку-машинисту (или undefined)
function getControlledTrain(player) {
  if (!player.hasTag(DRIVER_TAG)) return undefined;
  const found = player.dimension.getEntities({
    families: [TRAIN_FAMILY],
    location: player.location,
    maxDistance: CONTROL_RADIUS,
    closest: 1,
  });
  return found.length > 0 ? found[0] : undefined;
}

function notchText(notch) {
  if (notch > 0) return "Газ " + notch;
  if (notch < 0) return "Тормоз " + -notch;
  return "Нейтраль";
}

// =====================================================
//  ГУДОК
// =====================================================
function playHorn(train) {
  // звук гудка берём у самого поезда: "horn." + id поезда (двоеточие -> точка)
  // например, для mmt:train_red это "horn.mmt.train_red"
  // если у поезда такого звука нет, ничего не произойдёт
  const hornSound = "horn." + train.typeId.replace(":", ".");
  const l = train.location;
  train.dimension.runCommand(
    "playsound " + hornSound + " @a " + l.x + " " + l.y + " " + l.z + " 4 1"
  );
}

// =====================================================
//  ПКМ ПО ПРЕДМЕТАМ
// =====================================================
world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const id = event.itemStack.typeId;
  if (!id.startsWith("mmt:")) return;

  // защита от двойного срабатывания одного нажатия
  const now = system.currentTick;
  if (now - (lastPress.get(player.id) ?? -100) < PRESS_COOLDOWN) return;
  lastPress.set(player.id, now);

  if (!player.hasTag(DRIVER_TAG)) {
    player.sendMessage("§cНужен тег машиниста: /tag @s add " + DRIVER_TAG);
    return;
  }
  const train = getControlledTrain(player);
  if (!train) {
    player.sendMessage("§cРядом нет поезда (радиус " + CONTROL_RADIUS + " блоков)");
    return;
  }
  const st = getTrainState(train);

  if (id === "mmt:gas") {
    st.notch = Math.min(MAX_NOTCH, st.notch + 1);
  } else if (id === "mmt:brake") {
    st.notch = Math.max(MIN_NOTCH, st.notch - 1);
  } else if (id === "mmt:neutral") {
    st.notch = 0;
  } else if (id === "mmt:reverse") {
    if (st.speed === 0) {
      st.dir = -st.dir;
      st.hx = -st.hx;
      st.hz = -st.hz;
    } else {
      player.sendMessage("§cРеверс только при полной остановке");
    }
  } else if (id === "mmt:horn") {
    const last = lastHorn.get(train.id) ?? -1000;
    if (now - last >= HORN_COOLDOWN) {
      lastHorn.set(train.id, now);
      playHorn(train);
    }
  }
});

// =====================================================
//  ЗВУКИ ХОДА
// =====================================================
// Сами звуки лежат в аддоне с поездом. Имя звука: ключ + "." + id поезда
// (двоеточие -> точка), например "run3.mmt.train" или "base.mmt.train".
// Длину звука (в тиках) поезд сообщает через своё свойство "mmt:len_<ключ>".
// Если у поезда такого звука или свойства нет, он просто молчит.
const SOUND_VOLUME = 4;  // 4 = слышно примерно на 64 блока
const SOUND_OVERLAP = 4; // на сколько тиков следующий повтор накладывается на предыдущий

// Ступени разгона: пока включён газ, звук выбирается по скорости (км/ч)
const RUN_STEPS = [
  { key: "run1", upTo: 10 },
  { key: "run3", upTo: 25 },
  { key: "run4", upTo: 40 },
  { key: "run5", upTo: 55 },
  { key: "run6", upTo: 1000 },
];

function soundName(train, key) {
  return key + "." + train.typeId.replace(":", ".");
}

function stopTrainSound(train, key) {
  train.dimension.runCommand("stopsound @a " + soundName(train, key));
}

function updateTrainSound(train, st, now) {
  // 1) какой звук должен играть сейчас
  let key = null;
  if (st.speed > 0.05) {
    if (st.notch > 0) {
      for (const step of RUN_STEPS) {
        if (st.speed < step.upTo) {
          key = step.key;
          break;
        }
      }
    } else {
      key = "base"; // едет без газа (нейтраль или торможение)
    }
  }

  // 2) стоим: выключаем длинный звук хода
  if (key === null) {
    if (st.soundKey === "base") stopTrainSound(train, "base");
    st.soundKey = null;
    return;
  }

  // 3) тот же звук ещё играет: ждём
  const changed = key !== st.soundKey;
  if (!changed && now < st.soundNext) return;

  // 4) звук сменился: длинный "base" обрываем, короткие дозвучат сами
  if (changed && st.soundKey === "base") stopTrainSound(train, "base");

  // 5) длина звука из свойства поезда
  let len = 0;
  try {
    len = Number(train.getProperty("mmt:len_" + key));
  } catch (e) {
    len = 0;
  }
  st.soundKey = key;
  if (!(len > 0)) {
    st.soundNext = now + 40; // у поезда нет такого звука, проверим позже
    return;
  }

  // 6) тон "base" растёт со скоростью
  const pitch = key === "base" ? 0.85 + 0.45 * (st.speed / MAX_SPEED) : 1;
  const l = train.location;
  train.dimension.runCommand(
    "playsound " + soundName(train, key) + " @a " + l.x + " " + l.y + " " + l.z +
    " " + SOUND_VOLUME + " " + pitch.toFixed(2)
  );
  st.soundNext = now + Math.max(4, Math.floor(len / pitch) - SOUND_OVERLAP);
}

// =====================================================
//  УДАР ПО ПОЕЗДУ: один удар - поезд исчезает
// =====================================================
world.afterEvents.entityHurt.subscribe((event) => {
  const entity = event.hurtEntity;
  if (!entity) return;
  const family = entity.getComponent("minecraft:type_family");
  if (!family || !family.hasTypeFamily(TRAIN_FAMILY)) return;
  trainStates.delete(entity.id); // забываем его состояние
  entity.remove();               // убираем поезд из мира
});

// =====================================================
//  КАЖДЫЙ ТИК
// =====================================================
system.runInterval(() => {
  // 1) считаем скорость и двигаем все поезда
  for (const dimName of DIMENSIONS) {
    let dim;
    try {
      dim = world.getDimension(dimName);
    } catch (e) {
      continue;
    }
    for (const train of dim.getEntities({ families: [TRAIN_FAMILY] })) {
      try {
        const st = getTrainState(train);

        st.speed += ACCEL[String(st.notch)];
        st.speed = Math.max(0, Math.min(MAX_SPEED, st.speed));

        const dist = st.speed / 3.6 / 20; // блоков за тик
        if (dist > 0 || !st.placed) {
          const blocked = advanceTrain(train, st, dist);
          if (blocked && st.speed > 0) {
            // упёрлись в конец пути
            st.speed = 0;
            st.notch = 0;
          }
        }

        updateTrainSound(train, st, system.currentTick);
      } catch (e) {
        console.warn("MMT train error: " + e);
      }
    }
  }

  // 2) показываем данные машинисту
  for (const player of world.getAllPlayers()) {
    const train = getControlledTrain(player);
    if (!train) continue;
    const st = getTrainState(train);

    const accel = ACCEL[String(st.notch)];
    const atLimit = (accel > 0 && st.speed >= MAX_SPEED) || (accel < 0 && st.speed <= 0);
    let deltaText;
    if (accel > 0 && !atLimit) deltaText = "§a+" + accel.toFixed(1) + " скорость";
    else if (accel < 0 && !atLimit) deltaText = "§c" + accel.toFixed(1) + " скорость";
    else deltaText = "§7±0 скорость";

    const dirText = st.dir > 0 ? "вперёд" : "назад";
    player.onScreenDisplay.setActionBar(
      "§e" + notchText(st.notch) + "§r | " + Math.round(st.speed) + " км/ч | " +
      deltaText + "§r | " + dirText
    );
  }
}, 1);
